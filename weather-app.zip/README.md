weather-app
===========
 7 day forecast app using Angular JS and Open Weather Map API
 
 To run app, download and unzip weather-app.zip file, then open index.html in any browser.

 You can also view the app here: http://natalieweesh.github.io/weather-app
